<?php


class Mostratela
{
    public function index()
    {
        echo '---------------------- '.'<br>';
<br>;
        echo '----------------------';
    }

    public function entrada2()
    {
        echo 'Metodo entrada 2';
    }
}
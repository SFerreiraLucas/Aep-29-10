<?php


class Mostratela
{
    public function index()
    {
        echo '----------------------------<br>';
        echo 'Funcionando 100% 2019<br>';
        echo '----------------------------';
    }

    public function menu()
    {
         echo '----------------------------<br>';
        echo 'PRESS KEY<br>';
        echo '----------------------------';
    }
}